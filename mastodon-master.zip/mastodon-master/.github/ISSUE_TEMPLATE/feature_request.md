---
name: Feature Request
about: Suggest an idea for this project

---

[Issue text goes here].

* * * *

- [ ] I searched or browsed the repo’s other issues to ensure this is not a duplicate.
